<?php include('include/home/header.php'); ?>
	
	<section>
		<div class="container">
			<div class="row">
				<?php include('include/home/sidebar.php'); ?>
				
                <?php include('cart/data.php');
                
                ?>
				<div class="col-sm-9 padding-right">
					<div class="alert alert-success">
					   <h3 class="text-center"><i class="fa fa-check-circle fa-lg"></i> Your order has been submitted! Thank you for Shopping!</h3>
                    </div>
				</div>
			</div>
		</div>
		</div>
	</section>
	
	<?php include('include/home/footer.php'); ?>
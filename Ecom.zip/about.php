<?php include('include/home/header.php'); ?>
	
	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>About Us</h2>
						<address>
	    					<p>Company Name</p>
							<p>Address</p>
							<p>Mobile:</p>
							<p>Fax:</p>
							<p>Email: </p>
	    				</address>
					</div><!--/login form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
	
	
<?php include('include/home/footer.php'); ?>